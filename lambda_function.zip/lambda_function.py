import boto3

def handler(event, context):
    auto_scaling_group_name = "doodle-asg"
    # Create an Auto Scaling client
    autoscaling = boto3.client('autoscaling')
    # Trigger an instance refresh
    response = autoscaling.start_instance_refresh(
        AutoScalingGroupName=auto_scaling_group_name,
        Strategy='Rolling',
    )
    print(response)
    return {
        'statusCode': 200,
        'body': 'Instance refresh triggered successfully!'
    }
